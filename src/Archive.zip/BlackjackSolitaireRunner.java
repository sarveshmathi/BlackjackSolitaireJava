

/**
 * Blackjack solitaire runner class that starts the game
 * @author sarvesh
 *
 */

public class BlackjackSolitaireRunner {

	/**
	 * Let's the user a play a game of Blackjack Solitaire!
	 * @param args
	 */

	public static void main(String[] args) {
		BlackjackSolitaire bjs = new BlackjackSolitaire();
		bjs.play(); 
		
	}

}
